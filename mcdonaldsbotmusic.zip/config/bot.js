module.exports = {
  emojis: {
    off: ':x:',
    error: ':warning:',
    queue: ':bar_chart:',
    music: ':musical_note:',
    success: ':white_check_mark:',
  },

  discord: {
    token: 'Nzc2MjQxNDI1NDIyNjE0NTM5.X6yBKQ.B0yrxvuov_V2l0JsU0NvsLCTcWc',
    prefix: '!!',
    activity: 'McDonalds V1',
  },

  filters: ['8D', 'gate', 'haas', 'phaser', 'treble', 'tremolo', 'vibrato', 'reverse', 'karaoke', 'flanger', 'mcompand', 'pulsator', 'subboost', 'bassboost', 'vaporwave', 'nightcore', 'normalizer', 'surrounding'],
};